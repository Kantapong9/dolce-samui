<?php
/**
 * Agency Contacts API Endpoints
 * 
 * GET    /api/agency-contacts      - Get all contacts
 * GET    /api/agency-contacts/:id  - Get contact by ID
 * POST   /api/agency-contacts      - Create new contact
 */

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Remove base paths
$basePaths = ['/backend/api', '/dolce-samui/backend/api', '/api'];
foreach ($basePaths as $basePath) {
    if (strpos($path, $basePath) === 0) {
        $path = substr($path, strlen($basePath));
        break;
    }
}

$path = trim($path, '/');
$routes = $path ? explode('/', $path) : [];

$conn = getDBConnection();

if (!$conn) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล'
    ]);
    exit();
}

// Get contact by ID
if ($method === 'GET' && isset($routes[1]) && is_numeric($routes[1])) {
    $id = intval($routes[1]);
    
    $stmt = $conn->prepare("SELECT * FROM agency_contacts WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'ไม่พบข้อมูล'
        ]);
    } else {
        $contact = $result->fetch_assoc();
        echo json_encode([
            'success' => true,
            'data' => $contact
        ]);
    }
    
    $stmt->close();
    exit();
}

// Get all contacts
if ($method === 'GET') {
    $result = $conn->query("SELECT * FROM agency_contacts ORDER BY created_at DESC");
    
    $contacts = [];
    while ($row = $result->fetch_assoc()) {
        $contacts[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'data' => $contacts
    ]);
    exit();
}

// Create new contact
if ($method === 'POST') {
    // Get JSON input
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    if (!$data) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Invalid JSON data'
        ]);
        exit();
    }
    
    $firstName = $data['firstName'] ?? '';
    $lastName = $data['lastName'] ?? '';
    $agencyName = $data['agencyName'] ?? '';
    $details = $data['details'] ?? '';
    
    // Validation
    if (empty($firstName) || empty($lastName) || empty($agencyName)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'กรุณากรอกชื่อ นามสกุล และชื่อ Agency'
        ]);
        exit();
    }
    
    // Sanitize input
    $firstName = $conn->real_escape_string($firstName);
    $lastName = $conn->real_escape_string($lastName);
    $agencyName = $conn->real_escape_string($agencyName);
    $details = $conn->real_escape_string($details);
    
    // Insert into database
    $stmt = $conn->prepare("INSERT INTO agency_contacts (first_name, last_name, agency_name, details) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $firstName, $lastName, $agencyName, $details);
    
    if ($stmt->execute()) {
        $insertId = $conn->insert_id;
        
        echo json_encode([
            'success' => true,
            'message' => 'บันทึกข้อมูลสำเร็จ',
            'data' => [
                'id' => $insertId,
                'firstName' => $data['firstName'],
                'lastName' => $data['lastName'],
                'agencyName' => $data['agencyName'],
                'details' => $data['details'] ?? ''
            ]
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'เกิดข้อผิดพลาดในการบันทึกข้อมูล',
            'error' => $conn->error
        ]);
    }
    
    $stmt->close();
    exit();
}

// Method not allowed
http_response_code(405);
echo json_encode([
    'success' => false,
    'message' => 'Method not allowed'
]);
