<?php
/**
 * Health Check Endpoint
 * GET /api/health
 */

$conn = getDBConnection();

if (!$conn) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database connection failed',
        'database' => 'MySQL'
    ]);
    exit();
}

// Test database connection
$result = $conn->query("SELECT NOW() as server_time, DATABASE() as database_name");

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    echo json_encode([
        'status' => 'ok',
        'message' => 'Server is running',
        'database' => 'MySQL',
        'serverTime' => $row['server_time'],
        'databaseName' => $row['database_name']
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database query failed',
        'database' => 'MySQL'
    ]);
}
